import React from "react";

export default function Header() {
  return (
    <div className="chat_header">
      <h1>My Chat App - Scaledrone</h1>
    </div>
  );
}
